import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String userInput =input.next();
        int[] freq=new int[26];
        for (int i=0;i<userInput.length();i++)
            freq[userInput.charAt(i)-'a']++;
        for (int i =0; i<freq.length;i++)
            System.out.println((char) (i+'a') +" : "+freq[i]);

        for (int i =0;i <freq.length; i++)
            if (freq[i] !=0)
                for (int j =0;j < freq[i];j++);

            //System.out.print((char) (i+'a')+" : "+freq[i]);


        }
    private static int getMax(int[] array) {
        int max = array[0];
        for (int i = 1; i < array.length; i++)
            if (array[i] > max)
                max = array[i];
        return max;
    }
    }
